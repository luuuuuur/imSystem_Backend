from .rustjson import *

__doc__ = rustjson.__doc__
if hasattr(rustjson, "__all__"):
    __all__ = rustjson.__all__